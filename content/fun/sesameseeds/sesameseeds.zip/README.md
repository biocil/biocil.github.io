# sesameseeds

Like the coffee-stains package, but for people who read papers over a **simit**.
Each page gets a random but reproducible scatter of oven-roasted sesame seeds
and crumbs of crust, as if an academic ate a simit over the printout. A baked
simit is dry (its pekmez caramelised in the oven), so it sheds debris but
leaves no stain.

## Install

Put `sesameseeds.sty` next to your `.tex` file, or in your local texmf tree
(`~/Library/texmf/tex/latex/sesameseeds/` on macOS, `~/texmf/tex/latex/sesameseeds/` on Linux).
You need LaTeX 2020-10 or newer, TikZ and pgfopts (both included in TeX Live and MiKTeX).
It is tested with pdfLaTeX, XeLaTeX and LuaLaTeX.

## Use

```latex
\usepackage[mess=medium]{sesameseeds}   % none | light | medium | heavy | catastrophic
```

The automatic mess appears on every page without a second run. Some other examples:

```latex
\usepackage[heavy, randomseed=42, black=0.1, firstpage=false]{sesameseeds}

\sesamesetup{mess=catastrophic}               % applies to pages shipped from now on
\nosesame                                     % this page was read with a napkin
\sesameoff ... \sesameon                      % pause and resume the mess

% Placed by hand, in coordinates from the bottom-left corner of the page.
% These use `remember picture`, so compile twice.
\sesamesprinkle[count=25, spread=1.5cm]{14cm}{6cm}
\simitring[radius=6cm]{10.5cm}{15cm}          % ring of seeds and crumbs where it was put down
\sesameseed[angle=30, roast=0.9]{3cm}{3cm}
```

For the camera-ready version, `\usepackage[off]{sesameseeds}` turns everything off,
including the debris you placed by hand.

## Options

| key | default | meaning |
|---|---|---|
| `mess` | `medium` | `none`, `light`, `medium`, `heavy` or `catastrophic` (the bare words work too) |
| `off` | | turn everything off, hand-placed debris included |
| `seeds` | | a fixed number of seeds per page |
| `probability` | 0.8 | chance that a page gets anything at all |
| `randomseed` | 1525 | change it to get a different mess that is still reproducible |
| `crumbs` | true | crumbs of caramelised crust |
| `layer` | foreground | `background` puts the seeds under the text |
| `firstpage` | true | allow seeds on the title page |
| `size`, `spread`, `stray` | 1, 2.5cm, 0.2 | seed size, size of the fall-out zone, fraction of seeds that bounced away |
| `roast`, `black` | 0.5, 0 | golden (0) to deep-brown (1) roast, fraction of black sesame |
| `crumbratio`, `shadow` | 0.35, 0.28 | crumbs per seed, shadow opacity |
| `count`, `radius`, `angle` | 15 / 60, 6.5cm, random | for the manual commands (`count` is 15 for a sprinkle, 60 for a ring) |

`sesameseeds-demo.tex` and its PDF show every feature. Afiyet olsun.
